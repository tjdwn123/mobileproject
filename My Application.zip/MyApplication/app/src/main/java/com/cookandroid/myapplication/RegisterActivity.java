package com.cookandroid.myapplication; // ★주의: 본인 프로젝트 패키지명으로 꼭 확인하세요!

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    // 1. 사용할 변수 선언
    private EditText etName, etEmail, etPass;
    private Button btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ★ 수정됨: activity_resgister -> activity_register (오타 수정)
        // XML 파일 이름이 'activity_register.xml'이라고 가정합니다.
        setContentView(R.layout.activity_resgister);

        // 2. XML 디자인의 아이디와 연결 (findViewById)
        etName = findViewById(R.id.et_reg_name);
        etEmail = findViewById(R.id.et_reg_email);
        etPass = findViewById(R.id.et_reg_pass);
        btnRegister = findViewById(R.id.btn_reg_finish);

        // 3. '가입하기' 버튼 눌렀을 때의 동작
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 입력된 텍스트 가져오기
                String strName = etName.getText().toString();
                String strEmail = etEmail.getText().toString();
                String strPass = etPass.getText().toString();

                // 빈 칸 검사 (하나라도 비어있으면 경고)
                if (strName.isEmpty() || strEmail.isEmpty() || strPass.isEmpty()) {
                    Toast.makeText(RegisterActivity.this, "모든 정보를 입력해주세요.", Toast.LENGTH_SHORT).show();
                } else {
                    // 성공 메시지 띄우기
                    Toast.makeText(RegisterActivity.this, "회원가입에 성공했습니다!", Toast.LENGTH_SHORT).show();

                    // finish()를 호출하면 현재 회원가입 창이 닫히고,
                    // 이전 화면(로그인 화면)이 다시 보입니다.
                    finish();
                }
            }
        });
    }
}
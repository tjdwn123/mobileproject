package com.cookandroid.myapplication; // [중요] 본인 패키지 이름으로 꼭 맞추세요!

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // [1] 화면 연결: 만약 로그인 화면 파일명이 activity_main.xml 이라면 아래처럼 씁니다.
        // (activity_login.xml로 이름을 바꿨다면 R.layout.activity_login 이라고 쓰세요)
        setContentView(R.layout.activity_main);

        // [2] 찾아오기: XML에 있는 "회원가입" 글자를 찾아옵니다.
        TextView tvRegister = findViewById(R.id.textViewRegister);

        // [3] 클릭 리스너 연결: 글자를 눌렀을 때 할 일을 정합니다.
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // [핵심!] 연결 도구(Intent) 생성
                // new Intent(현재화면.this, 이동할화면.class);
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);

                // 출발!
                startActivity(intent);
            }
        });
    }
}
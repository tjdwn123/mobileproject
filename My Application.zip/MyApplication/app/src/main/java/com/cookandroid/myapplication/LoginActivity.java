package com.cookandroid.myapplication; // 패키지명 확인

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast; // 토스트 메시지를 위해 추가
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ★ 중요: 본인의 로그인 XML 파일 이름을 적으세요.
        // (activity_main.xml 이라면 그대로 두시고, activity_login.xml 이라면 수정하세요)
        setContentView(R.layout.activity_main);

        // ---------------------------------------------------------
        // 1. [회원가입] 버튼 기능 (요청하신 부분)
        // ---------------------------------------------------------
        Button btnGoRegister = findViewById(R.id.btn_go_register);

        btnGoRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // LoginActivity에서 -> RegisterActivity로 이동
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        // ---------------------------------------------------------
        // 2. [로그인] 버튼 기능 (화면에 버튼이 있으므로 연결해두는 것이 좋습니다)
        // ---------------------------------------------------------
        Button btnLogin = findViewById(R.id.buttonLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 아직 로그인 기능은 없으므로 메시지만 띄웁니다.
                Toast.makeText(LoginActivity.this, "로그인 버튼을 눌렀습니다.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
package com.cookandroid.myapplication11; // 본인 패키지 이름 확인!

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class FavoriteActivity extends AppCompatActivity {

    // 아이템들을 담을 레이아웃 변수
    LinearLayout layoutLotte, layoutHanok, layoutBusan, layoutUlsan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);

        // 1. 뒤로가기 버튼 기능 (메인으로 복귀)
        ImageView btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // 현재 화면 닫기
            }
        });

        // 2. 레이아웃 찾기
        layoutLotte = findViewById(R.id.itemLotte);
        layoutHanok = findViewById(R.id.itemHanok);
        layoutBusan = findViewById(R.id.itemBusan);
        layoutUlsan = findViewById(R.id.itemUlsan);

        // 3. 검색 기능 구현
        EditText etSearch = findViewById(R.id.etSearch);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // 검색어가 바뀔 때마다 실행되는 함수
                String searchText = s.toString();
                filterList(searchText);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    // 검색어에 따라 보여줄지 말지 결정하는 함수
    void filterList(String text) {
        // 1. 롯데월드
        if (text.isEmpty() || "롯데월드".contains(text)) {
            layoutLotte.setVisibility(View.VISIBLE);
        } else {
            layoutLotte.setVisibility(View.GONE);
        }

        // 2. 한옥마을
        if (text.isEmpty() || "한옥마을".contains(text)) {
            layoutHanok.setVisibility(View.VISIBLE);
        } else {
            layoutHanok.setVisibility(View.GONE);
        }

        // 3. 부산 해운대
        if (text.isEmpty() || "부산 해운대".contains(text)) {
            layoutBusan.setVisibility(View.VISIBLE);
        } else {
            layoutBusan.setVisibility(View.GONE);
        }

        // 4. 울산
        if (text.isEmpty() || "울산".contains(text)) {
            layoutUlsan.setVisibility(View.VISIBLE);
        } else {
            layoutUlsan.setVisibility(View.GONE);
        }
    }
}
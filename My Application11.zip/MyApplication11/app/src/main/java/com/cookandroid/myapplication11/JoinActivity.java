package com.cookandroid.myapplication11; // 패키지명 확인!

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class JoinActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);

        // 뷰 찾기
        EditText etId = findViewById(R.id.etJoinId);
        EditText etPass = findViewById(R.id.etJoinPass);
        EditText etPassCheck = findViewById(R.id.etJoinPassCheck);
        Button btnFinish = findViewById(R.id.btnJoinFinish);

        // 회원가입 버튼 클릭 이벤트
        btnFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = etId.getText().toString();
                String pass = etPass.getText().toString();
                String passCheck = etPassCheck.getText().toString();

                // 1. 빈칸 검사
                if (id.isEmpty() || pass.isEmpty() || passCheck.isEmpty()) {
                    Toast.makeText(JoinActivity.this, "모든 정보를 입력해주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // 2. 비밀번호 일치 검사 (핵심 기능!)
                if (!pass.equals(passCheck)) {
                    // 비밀번호가 다르면 경고 메시지 띄우기
                    Toast.makeText(JoinActivity.this, "비밀번호가 일치하지 않습니다!", Toast.LENGTH_SHORT).show();
                    return; // 함수 종료 (다음 단계로 안 넘어감)
                }

                // 3. 성공 시 처리
                Toast.makeText(JoinActivity.this, "회원가입 성공! 로그인 해주세요.", Toast.LENGTH_SHORT).show();
                finish(); // 현재 화면(JoinActivity)을 끄고 이전 화면(LoginActivity)으로 돌아감
            }
        });
    }
}
package com.cookandroid.myapplication11; // 패키지 이름 확인

import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MapActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map); // 수정된 xml 연결

        // 1. 검색어 받기
        String keyword = getIntent().getStringExtra("keyword");
        if (keyword == null || keyword.isEmpty()) {
            keyword = "서울";
        }

        // 2. 상단 제목에 검색어 표시 (예: "강남 위치 정보")
        TextView tvMapTitle = findViewById(R.id.tvMapTitle);
        tvMapTitle.setText(keyword + " 위치");

        // 3. 뒤로가기 버튼 기능 구현
        ImageView btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // 현재 화면(지도)을 끄고 이전 화면으로 돌아감
            }
        });

        // 4. 웹뷰 설정 (지도 띄우기)
        WebView webView = findViewById(R.id.webView);
        if (webView != null) {
            webView.setWebViewClient(new WebViewClient());
            WebSettings webSettings = webView.getSettings();
            webSettings.setJavaScriptEnabled(true); // 자바스크립트 허용

            // 네이버 지도 검색 URL
            webView.loadUrl("https://m.map.naver.com/search2/search.naver?query=" + keyword);
        }

        Toast.makeText(this, keyword + " 지도를 불러옵니다.", Toast.LENGTH_SHORT).show();
    }
}
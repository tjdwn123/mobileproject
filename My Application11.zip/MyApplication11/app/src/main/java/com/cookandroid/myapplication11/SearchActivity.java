package com.cookandroid.myapplication11;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class SearchActivity extends AppCompatActivity {

    EditText etSearchInput;
    ListView listView;
    TextView tvListTitle;
    ArrayAdapter<String> adapter;
    ArrayList<String> listItems;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search); // 이제 에러 안 날 겁니다!

        etSearchInput = findViewById(R.id.etSearchInput);
        listView = findViewById(R.id.listViewSearch);
        tvListTitle = findViewById(R.id.tvListTitle);
        ImageView btnBack = findViewById(R.id.btnBack);
        ImageView btnClear = findViewById(R.id.btnClear);
        ImageView btnSearchAction = findViewById(R.id.btnSearchAction);

        listItems = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listItems);
        listView.setAdapter(adapter);

        loadSearchHistory();

        // 돋보기 버튼 누르면 지도로 이동 (MapActivity로)
        btnSearchAction.setOnClickListener(v -> {
            String keyword = etSearchInput.getText().toString();
            Intent intent = new Intent(SearchActivity.this, MapActivity.class);
            intent.putExtra("keyword", keyword);
            startActivity(intent);
        });

        // (기타 기능: 뒤로가기, 지우기, 텍스트 감지 등)
        btnBack.setOnClickListener(v -> finish());
        btnClear.setOnClickListener(v -> etSearchInput.setText(""));

        etSearchInput.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String text = s.toString().trim();
                if (text.equals("서울")) {
                    listItems.clear(); listItems.add("강남"); listItems.add("미아사거리");
                    adapter.notifyDataSetChanged();
                } else if (text.equals("부산")) {
                    listItems.clear(); listItems.add("해운대"); listItems.add("국밥");
                    adapter.notifyDataSetChanged();
                }
            }
            public void afterTextChanged(Editable s) {}
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            String selected = listItems.get(position);
            Intent intent = new Intent(SearchActivity.this, MapActivity.class);
            intent.putExtra("keyword", selected);
            startActivity(intent);
        });
    }

    void loadSearchHistory() {
        sharedPreferences = getSharedPreferences("SearchHistoryPref", MODE_PRIVATE);
        // 간단한 구현
    }
}
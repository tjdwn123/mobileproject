package com.cookandroid.myapplication11;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private TextView tvTodayMemo, tvTomorrowMemo;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ==========================================
        // 1. 사이드 메뉴 (햄버거 버튼 & 드로어) 복구
        // ==========================================
        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ImageView btnMenu = findViewById(R.id.btnMenu);

        // 햄버거 버튼 누르면 서랍 열기
        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        // 사이드 메뉴 아이템 클릭 시 동작
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();

                if (id == R.id.nav_home) {
                    drawerLayout.closeDrawer(GravityCompat.START); // 홈은 서랍 닫기
                } else if (id == R.id.nav_favorites) {
                    Intent intent = new Intent(MainActivity.this, FavoriteActivity.class);
                    startActivity(intent);
                } else if (id == R.id.nav_importance) {
                    Toast.makeText(MainActivity.this, "Importance 메뉴", Toast.LENGTH_SHORT).show();
                } else if (id == R.id.nav_notification) {
                    Toast.makeText(MainActivity.this, "알림 메뉴", Toast.LENGTH_SHORT).show();
                } else if (id == R.id.nav_setting) {
                    Toast.makeText(MainActivity.this, "설정 메뉴", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        // ==========================================
        // 2. 메모장 기능 (Today / Tomorrow) 유지
        // ==========================================
        CardView cardToday = findViewById(R.id.cardToday);
        CardView cardTomorrow = findViewById(R.id.cardTomorrow);
        tvTodayMemo = findViewById(R.id.tvTodayMemo);
        tvTomorrowMemo = findViewById(R.id.tvTomorrowMemo);

        // 저장된 메모 불러오기
        sharedPreferences = getSharedPreferences("TripMemo", MODE_PRIVATE);
        tvTodayMemo.setText(sharedPreferences.getString("today", "터치하여 일정을 입력하세요..."));
        tvTomorrowMemo.setText(sharedPreferences.getString("tomorrow", "터치하여 일정을 입력하세요..."));

        // 카드 클릭 시 입력창 띄우기
        cardToday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMemoDialog("Today 일정 수정", "today", tvTodayMemo);
            }
        });

        cardTomorrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMemoDialog("Tomorrow 일정 수정", "tomorrow", tvTomorrowMemo);
            }
        });

        // ==========================================
        // 3. 하단 네비게이션 바 (검색, 즐겨찾기 연결) 복구
        // ==========================================
        BottomNavigationView bottomNav = findViewById(R.id.bottomNavigation);
        if (bottomNav != null) {
            bottomNav.setOnItemSelectedListener(new BottomNavigationView.OnItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    int id = item.getItemId();

                    if (id == R.id.nav_search) {
                        // ★ 돋보기 누르면 검색 화면으로 이동
                        Intent intent = new Intent(MainActivity.this, SearchActivity.class);
                        startActivity(intent);
                        return true;
                    } else if (id == R.id.nav_fav) {
                        // 하트 누르면 즐겨찾기 화면으로 이동
                        Intent intent = new Intent(MainActivity.this, FavoriteActivity.class);
                        startActivity(intent);
                        return true;
                    } else if (id == R.id.nav_info) {
                        Toast.makeText(MainActivity.this, "정보", Toast.LENGTH_SHORT).show();
                        return true;
                    } else if (id == R.id.nav_noti) {
                        Toast.makeText(MainActivity.this, "알림", Toast.LENGTH_SHORT).show();
                        return true;
                    } else if (id == R.id.nav_set) {
                        Toast.makeText(MainActivity.this, "설정", Toast.LENGTH_SHORT).show();
                        return true;
                    }
                    return false;
                }
            });
        }
    }

    // 뒤로가기 버튼 눌렀을 때 서랍이 열려있으면 닫기
    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    // 메모 입력 팝업창 함수
    private void showMemoDialog(String title, String key, TextView textView) {
        final EditText input = new EditText(this);
        input.setText(textView.getText());
        input.setPadding(50, 50, 50, 50);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setView(input);

        builder.setPositiveButton("저장", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String newText = input.getText().toString();
                textView.setText(newText);

                // 내부 저장소에 저장
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(key, newText);
                editor.apply();
            }
        });

        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }
}
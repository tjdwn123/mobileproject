package com.cookandroid.myapplication;

import android.app.Activity;

public class RegisterActivity extends Activity {
}

package com.cookandroid.myapplication; // 본인의 패키지 이름으로 변경하세요

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    // 1. XML 뷰들을 제어할 변수 선언
    private EditText editTextEmail;
    private EditText editTextPassword;
    private Button buttonLogin;
    private TextView textViewRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 2. XML 레이아웃 파일을 화면에 연결
        setContentView(R.layout.activity_login);

        // 3. XML의 뷰들을 ID로 찾아와서 변수와 연결
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        textViewRegister = findViewById(R.id.textViewRegister);

        // 4. 로그인 버튼 클릭 이벤트 처리
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 5. 사용자가 입력한 이메일과 비밀번호 가져오기
                String email = editTextEmail.getText().toString().trim();
                String password = editTextPassword.getText().toString().trim();

                // 6. 간단한 유효성 검사 (비어있는지)
                if (email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "이메일과 비밀번호를 모두 입력해주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // [중요] TODO: 여기에 실제 로그인 로직 구현
                // (예: Firebase Authentication, 자체 서버 API 호출 등)
                // 지금은 성공했다고 가정하고 토스트 메시지를 띄웁니다.

                // 로그인 성공 시 처리 (예: 메인 화면으로 이동)
                Toast.makeText(LoginActivity.this, "로그인 성공!", Toast.LENGTH_SHORT).show();

                // Intent를 사용해 메인 화면(MainActivity)으로 이동
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);

                // finish()를 호출하여 로그인 화면을 종료 (뒤로가기 시 다시 안 보이게)
                finish();
            }
        });

        // 7. 회원가입 텍스트 클릭 이벤트 처리
        textViewRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: 회원가입 화면(RegisterActivity)으로 이동하는 로직 구현

                // 아래 두 줄의 주석 '//'를 제거합니다.
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);

                // 이 Toast 메시지 줄은 삭제하거나 주석 처리합니다.
                // Toast.makeText(LoginActivity.this, "회원가입 화면으로 이동합니다.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}